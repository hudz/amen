
var ms = {
          packageBooked: ''
	}

$(document).ready(function(){
	$('#title_page').html("select package");
	$('#page_1 input').on('click', function(){
		ms.packageBooked = $(this).attr('data-package');
		$('#page_1').fadeOut();
		$('#page_2').fadeIn();
		$('#title_page').html("INSERT DETAILS");
	});
	
	$('#page_2 input').on('click', function(){
		$('#page_2').fadeOut();
		$('#page_3').fadeIn();
		$('#title_page').html("PAYMENT");
	})
		
});